Mob Loot Bags 2.0 - starter datapack
====================================

Pick the folder for your Minecraft version and copy it into <world>/datapacks/ (or a modpack's global datapack
folder), then run /reload. Each folder is a complete datapack in that version's format (1.20.1 uses the plural
folder names loot_tables/ and tags/items/; the paths below use the newer names).

What it shows:

1. A custom table, data/my_pack/loot_table/legendary_jackpot.json.
   Nothing uses it until you point a bag at it in config/mob_loot_bags/bags.json:
       "loot_tables": { "legendary": ["my_pack:legendary_jackpot"], ... }
   List several tables to pick one at random each time. Then /lootbags reload.

2. A dimension theme, data/mob_loot_bags/loot_table/bags/rare/the_aether.json.
   Bags roll mob_loot_bags:bags/<bag>/<dimension path> when it exists, so Rare bags dropped in a dimension
   called <anything>:the_aether use this table. The mod ships themes for the_nether and the_end; a file with the
   same path in your datapack replaces them, and mob_loot_bags:bags/<bag> replaces a bag's default table.

3. Bonus items, data/mob_loot_bags/tags/item/bonus/rare.json.
   Every tier rolls a bonus pool from #mob_loot_bags:bonus/<tier>. Add items there (keep "replace": false)
   to mix modded items into bags without rewriting any table.

Check your work in game:
    /lootbags simulate rare 1000            rolls the table a Rare bag would use and lists the odds
    /lootbags simulate rare 1000 the_aether the same, for the themed table
Hold Shift over a bag to see the same odds in its tooltip (refreshed on /reload).
