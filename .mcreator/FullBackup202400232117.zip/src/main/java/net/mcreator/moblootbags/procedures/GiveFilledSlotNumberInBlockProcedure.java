package net.mcreator.moblootbags.procedures;

import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.common.extensions.ILevelExtension;
import net.neoforged.neoforge.capabilities.Capabilities;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

public class GiveFilledSlotNumberInBlockProcedure {
	public static double execute(LevelAccessor world, double x, double y, double z) {
		double emptySlotId = 0;
		double itterator = 0;
		double FilledSlot = 0;
		FilledSlot = 99;
		itterator = 0;
		while (itterator <= 23) {
			if (new Object() {
				public int getAmount(LevelAccessor world, BlockPos pos, int slotid) {
					if (world instanceof ILevelExtension _ext) {
						IItemHandler _itemHandler = _ext.getCapability(Capabilities.ItemHandler.BLOCK, pos, null);
						if (_itemHandler != null)
							return _itemHandler.getStackInSlot(slotid).getCount();
					}
					return 0;
				}
			}.getAmount(world, BlockPos.containing(x, y, z), (int) itterator) > 0) {
				FilledSlot = itterator;
				break;
			}
			itterator = itterator + 1;
		}
		return FilledSlot;
	}
}
