
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.moblootbags.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.moblootbags.item.UncommonlootbagItem;
import net.mcreator.moblootbags.item.RarelootbagItem;
import net.mcreator.moblootbags.item.LegendarylootbagItem;
import net.mcreator.moblootbags.item.EpiclootbagItem;
import net.mcreator.moblootbags.item.CustomLootBagItem;
import net.mcreator.moblootbags.item.CommonlootbagItem;
import net.mcreator.moblootbags.MobLootBagsMod;

public class MobLootBagsModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(MobLootBagsMod.MODID);
	public static final DeferredHolder<Item, Item> COMMONLOOTBAG = REGISTRY.register("commonlootbag", CommonlootbagItem::new);
	public static final DeferredHolder<Item, Item> UNCOMMONLOOTBAG = REGISTRY.register("uncommonlootbag", UncommonlootbagItem::new);
	public static final DeferredHolder<Item, Item> RARELOOTBAG = REGISTRY.register("rarelootbag", RarelootbagItem::new);
	public static final DeferredHolder<Item, Item> EPICLOOTBAG = REGISTRY.register("epiclootbag", EpiclootbagItem::new);
	public static final DeferredHolder<Item, Item> LEGENDARYLOOTBAG = REGISTRY.register("legendarylootbag", LegendarylootbagItem::new);
	public static final DeferredHolder<Item, Item> LOOT_BAG_RECYCLE_BLOCK = block(MobLootBagsModBlocks.LOOT_BAG_RECYCLE_BLOCK);
	public static final DeferredHolder<Item, Item> LOOT_BAG_OPENER_BLOCK = block(MobLootBagsModBlocks.LOOT_BAG_OPENER_BLOCK);
	public static final DeferredHolder<Item, Item> CUSTOM_LOOT_BAG = REGISTRY.register("custom_loot_bag", CustomLootBagItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredHolder<Item, Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
