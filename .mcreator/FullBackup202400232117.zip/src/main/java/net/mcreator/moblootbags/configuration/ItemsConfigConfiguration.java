package net.mcreator.moblootbags.configuration;

import net.neoforged.neoforge.common.ModConfigSpec;

import java.util.List;

public class ItemsConfigConfiguration {
	public static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();
	public static final ModConfigSpec SPEC;
	public static final ModConfigSpec.ConfigValue<Double> MAX_AMOUNT_RARE;
	public static final ModConfigSpec.ConfigValue<List<? extends String>> VALUABLE_ITEMS;
	public static final ModConfigSpec.ConfigValue<Double> MAX_AMOUNT_COMMUN;
	static {
		BUILDER.push("Valuable");
		MAX_AMOUNT_RARE = BUILDER.define("max_amount_rare", (double) 5);
		VALUABLE_ITEMS = BUILDER.defineList("valuable_items", List.of("gold_ingot", "emerald", "diamond", "smithing_template"), entry -> true);
		MAX_AMOUNT_COMMUN = BUILDER.define("max_amount_commun", (double) 20);
		BUILDER.pop();

		SPEC = BUILDER.build();
	}

}
