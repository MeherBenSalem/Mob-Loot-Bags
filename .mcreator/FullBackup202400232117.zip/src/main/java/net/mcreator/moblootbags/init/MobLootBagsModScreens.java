
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.moblootbags.init;

import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.moblootbags.client.gui.LootbagRecyleBlockGUIScreen;
import net.mcreator.moblootbags.client.gui.LootbagOpenBlockGUIScreen;
import net.mcreator.moblootbags.client.gui.ChooseRewardGuiScreen;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class MobLootBagsModScreens {
	@SubscribeEvent
	public static void clientLoad(RegisterMenuScreensEvent event) {
		event.register(MobLootBagsModMenus.LOOTBAG_OPEN_BLOCK_GUI.get(), LootbagOpenBlockGUIScreen::new);
		event.register(MobLootBagsModMenus.LOOTBAG_RECYLE_BLOCK_GUI.get(), LootbagRecyleBlockGUIScreen::new);
		event.register(MobLootBagsModMenus.CHOOSE_REWARD_GUI.get(), ChooseRewardGuiScreen::new);
	}
}
