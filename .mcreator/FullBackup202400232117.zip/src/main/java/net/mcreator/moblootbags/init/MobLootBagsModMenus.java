
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.moblootbags.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.core.registries.Registries;

import net.mcreator.moblootbags.world.inventory.LootbagRecyleBlockGUIMenu;
import net.mcreator.moblootbags.world.inventory.LootbagOpenBlockGUIMenu;
import net.mcreator.moblootbags.world.inventory.ChooseRewardGuiMenu;
import net.mcreator.moblootbags.MobLootBagsMod;

public class MobLootBagsModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(Registries.MENU, MobLootBagsMod.MODID);
	public static final DeferredHolder<MenuType<?>, MenuType<LootbagOpenBlockGUIMenu>> LOOTBAG_OPEN_BLOCK_GUI = REGISTRY.register("lootbag_open_block_gui", () -> IMenuTypeExtension.create(LootbagOpenBlockGUIMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<LootbagRecyleBlockGUIMenu>> LOOTBAG_RECYLE_BLOCK_GUI = REGISTRY.register("lootbag_recyle_block_gui", () -> IMenuTypeExtension.create(LootbagRecyleBlockGUIMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<ChooseRewardGuiMenu>> CHOOSE_REWARD_GUI = REGISTRY.register("choose_reward_gui", () -> IMenuTypeExtension.create(ChooseRewardGuiMenu::new));
}
