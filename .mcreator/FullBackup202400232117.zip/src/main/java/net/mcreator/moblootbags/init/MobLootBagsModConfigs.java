package net.mcreator.moblootbags.init;

import net.neoforged.fml.event.lifecycle.FMLConstructModEvent;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.ModContainer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.IEventBus;

import net.mcreator.moblootbags.configuration.MainConfigFileConfiguration;
import net.mcreator.moblootbags.configuration.ItemsConfigConfiguration;
import net.mcreator.moblootbags.MobLootBagsMod;

@Mod(MobLootBagsMod.MODID)
@EventBusSubscriber(modid = MobLootBagsMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public class MobLootBagsModConfigs {
	private static ModContainer modContainer;

	public MobLootBagsModConfigs(IEventBus modEventBus, ModContainer container) {
		setModContainer(container);
	}

	@SubscribeEvent
	public static void register(FMLConstructModEvent event) {
		event.enqueueWork(() -> {
			modContainer.registerConfig(ModConfig.Type.COMMON, MainConfigFileConfiguration.SPEC, "MobLootBags/MobsLootTables.toml");
			modContainer.registerConfig(ModConfig.Type.COMMON, ItemsConfigConfiguration.SPEC, "MobLootBags/ItemsConfig.toml");
		});
	}

	public static void setModContainer(ModContainer container) {
		modContainer = container;
	}
}
