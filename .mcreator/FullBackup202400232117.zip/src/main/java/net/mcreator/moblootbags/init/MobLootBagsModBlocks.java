
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.moblootbags.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;

import net.mcreator.moblootbags.block.LootBagRecycleBlockBlock;
import net.mcreator.moblootbags.block.LootBagOpenerBlockBlock;
import net.mcreator.moblootbags.MobLootBagsMod;

public class MobLootBagsModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(MobLootBagsMod.MODID);
	public static final DeferredHolder<Block, Block> LOOT_BAG_RECYCLE_BLOCK = REGISTRY.register("loot_bag_recycle_block", LootBagRecycleBlockBlock::new);
	public static final DeferredHolder<Block, Block> LOOT_BAG_OPENER_BLOCK = REGISTRY.register("loot_bag_opener_block", LootBagOpenerBlockBlock::new);
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
